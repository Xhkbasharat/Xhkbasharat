# Driver Drowsiness Detection System

## Objective
Detect driver drowsiness in real time using a webcam and computer vision.

## Features
- Face detection
- Eye detection
- Drowsiness alert
- Real-time monitoring

## Technologies
- Python
- OpenCV
- NumPy

## Run
pip install -r requirements.txt
python drowsiness_detection.py
