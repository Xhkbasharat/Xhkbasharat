from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>Plant Disease Detection System</h1><p>Project Setup Ready</p>'

if __name__ == '__main__':
    app.run(debug=True)
