from flask import Flask

app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>Human Emotion Detection System</h1><p>Project Setup Ready</p>'

if __name__ == '__main__':
    app.run(debug=True)
