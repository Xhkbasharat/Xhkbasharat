import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score

# Sample dataset
data = pd.DataFrame({
    "label": ["spam", "ham", "spam", "ham"],
    "text": [
        "Win money now",
        "Hello friend how are you",
        "Claim your free prize",
        "Let's meet tomorrow"
    ]
})

X = data["text"]
y = data["label"]

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(X)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

model = MultinomialNB()
model.fit(X_train, y_train)

pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, pred))

msg = input("Enter a message: ")
msg_vec = vectorizer.transform([msg])
result = model.predict(msg_vec)[0]
print("Prediction:", result)
