import sqlite3

conn = sqlite3.connect('expenses.db')
cur = conn.cursor()

cur.execute('''
CREATE TABLE IF NOT EXISTS transactions(
id INTEGER PRIMARY KEY AUTOINCREMENT,
type TEXT,
amount REAL,
description TEXT
)
''')
conn.commit()

while True:
    print("\n1. Add Income")
    print("2. Add Expense")
    print("3. View Transactions")
    print("4. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        amount = float(input("Amount: "))
        desc = input("Description: ")
        cur.execute("INSERT INTO transactions(type,amount,description) VALUES(?,?,?)",
                    ("Income", amount, desc))
        conn.commit()

    elif choice == "2":
        amount = float(input("Amount: "))
        desc = input("Description: ")
        cur.execute("INSERT INTO transactions(type,amount,description) VALUES(?,?,?)",
                    ("Expense", amount, desc))
        conn.commit()

    elif choice == "3":
        for row in cur.execute("SELECT * FROM transactions"):
            print(row)

    elif choice == "4":
        break

conn.close()
