from flask import Flask

app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>Handwritten Digit Recognition System</h1><p>Project Setup Ready</p>'

if __name__ == '__main__':
    app.run(debug=True)
