# Signature Verification System

Verify whether a signature is genuine or forged using image processing and machine learning.

## Technologies
- Python
- OpenCV
- NumPy
- Flask

## Run
pip install -r requirements.txt
python app.py
