# Face Recognition Attendance System

## Features
- Face Detection
- Face Recognition
- Automatic Attendance
- CSV Attendance Reports

## Technologies
- Python
- OpenCV
- face_recognition
- Pandas
- NumPy

## Run
pip install -r requirements.txt
python attendance.py
