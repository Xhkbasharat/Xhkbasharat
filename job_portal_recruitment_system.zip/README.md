# Job Portal & Recruitment Management System

A full-stack recruitment platform built with Python, Flask, SQLite, HTML, CSS and JavaScript.

## Features
- Candidate, employer and administrator roles
- Registration and login
- Password hashing
- Job posting, editing and deletion
- Job search and filtering
- Resume uploads
- Online applications
- Application status management
- Separate dashboards
- SQLite database
- Responsive frontend

## Demo Admin
- Email: `admin@example.com`
- Password: `admin123`

Change the secret key and admin credentials before production use.

## Run locally

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Linux/macOS:
```bash
source venv/bin/activate
```

Install:
```bash
pip install -r requirements.txt
```

Run:
```bash
python app.py
```

Open:
`http://127.0.0.1:5000`

The SQLite database is automatically created at `instance/jobportal.db`.

## Main Routes
- `/` Home
- `/register` Registration
- `/login` Login
- `/jobs` Job search
- `/dashboard` Role-based dashboard
- `/employer/jobs/new` Create job
