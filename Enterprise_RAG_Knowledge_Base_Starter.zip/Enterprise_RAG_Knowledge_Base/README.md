# Enterprise RAG Knowledge Base

A Retrieval-Augmented Generation (RAG) platform for querying enterprise documents.
Upload PDFs, build a FAISS vector index, and ask questions using an LLM-backed pipeline.

## Features
- PDF ingestion
- Text chunking
- Embedding generation
- FAISS vector search
- Context-aware Q&A
- FastAPI backend
- Ready for Streamlit/React frontends

## Run
```bash
pip install -r requirements.txt
uvicorn main:app --reload
```