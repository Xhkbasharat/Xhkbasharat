from flask import Flask, render_template, request, redirect, url_for, session, flash, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
from pathlib import Path
from functools import wraps

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "instance" / "jobportal.db"
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.secret_key = "change-this-secret-key"
app.config["UPLOAD_FOLDER"] = str(UPLOAD_DIR)
ALLOWED_EXTENSIONS = {"pdf", "doc", "docx"}

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('candidate','employer','admin')),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        employer_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        company TEXT NOT NULL,
        location TEXT NOT NULL,
        description TEXT NOT NULL,
        skills TEXT,
        salary TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (employer_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        job_id INTEGER NOT NULL,
        candidate_id INTEGER NOT NULL,
        resume TEXT,
        cover_letter TEXT,
        status TEXT DEFAULT 'Applied',
        applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(job_id, candidate_id),
        FOREIGN KEY (job_id) REFERENCES jobs(id),
        FOREIGN KEY (candidate_id) REFERENCES users(id)
    );
    """)
    # Demo admin
    admin = conn.execute("SELECT id FROM users WHERE email=?", ("admin@example.com",)).fetchone()
    if not admin:
        conn.execute(
            "INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
            ("Administrator", "admin@example.com", generate_password_hash("admin123"), "admin")
        )
    conn.commit()
    conn.close()

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please login first.", "warning")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if "user_id" not in session:
                return redirect(url_for("login"))
            if session.get("role") not in roles:
                flash("You do not have permission to access this page.", "danger")
                return redirect(url_for("dashboard"))
            return view(*args, **kwargs)
        return wrapped
    return decorator

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.context_processor
def inject_user():
    return {"current_user": session.get("name"), "current_role": session.get("role")}

@app.route("/")
def index():
    conn = get_db()
    jobs = conn.execute("SELECT * FROM jobs ORDER BY created_at DESC LIMIT 6").fetchall()
    conn.close()
    return render_template("index.html", jobs=jobs)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form["name"].strip()
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        role = request.form["role"]

        if role not in ("candidate", "employer"):
            flash("Invalid role.", "danger")
            return redirect(url_for("register"))

        conn = get_db()
        try:
            conn.execute(
                "INSERT INTO users(name,email,password,role) VALUES(?,?,?,?)",
                (name, email, generate_password_hash(password), role)
            )
            conn.commit()
            flash("Registration successful. Please login.", "success")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("Email is already registered.", "danger")
        finally:
            conn.close()
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        conn = get_db()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()

        if user and check_password_hash(user["password"], password):
            session.clear()
            session.update({"user_id": user["id"], "name": user["name"], "role": user["role"]})
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.", "success")
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()
    if session["role"] == "candidate":
        jobs = conn.execute("SELECT * FROM jobs ORDER BY created_at DESC").fetchall()
        applications = conn.execute("""
            SELECT applications.*, jobs.title, jobs.company
            FROM applications JOIN jobs ON applications.job_id = jobs.id
            WHERE applications.candidate_id=? ORDER BY applications.applied_at DESC
        """, (session["user_id"],)).fetchall()
        conn.close()
        return render_template("candidate_dashboard.html", jobs=jobs, applications=applications)

    if session["role"] == "employer":
        jobs = conn.execute("SELECT * FROM jobs WHERE employer_id=? ORDER BY created_at DESC",
                            (session["user_id"],)).fetchall()
        applications = conn.execute("""
            SELECT applications.*, jobs.title, users.name AS candidate_name, users.email
            FROM applications
            JOIN jobs ON applications.job_id=jobs.id
            JOIN users ON applications.candidate_id=users.id
            WHERE jobs.employer_id=? ORDER BY applications.applied_at DESC
        """, (session["user_id"],)).fetchall()
        conn.close()
        return render_template("employer_dashboard.html", jobs=jobs, applications=applications)

    stats = {
        "users": conn.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        "jobs": conn.execute("SELECT COUNT(*) FROM jobs").fetchone()[0],
        "applications": conn.execute("SELECT COUNT(*) FROM applications").fetchone()[0],
        "employers": conn.execute("SELECT COUNT(*) FROM users WHERE role='employer'").fetchone()[0],
    }
    jobs = conn.execute("""
        SELECT jobs.*, users.name AS employer_name
        FROM jobs JOIN users ON jobs.employer_id=users.id
        ORDER BY jobs.created_at DESC
    """).fetchall()
    users = conn.execute("SELECT id,name,email,role,created_at FROM users ORDER BY created_at DESC").fetchall()
    conn.close()
    return render_template("admin_dashboard.html", stats=stats, jobs=jobs, users=users)

@app.route("/jobs")
def jobs():
    q = request.args.get("q", "").strip()
    location = request.args.get("location", "").strip()
    conn = get_db()
    sql = "SELECT * FROM jobs WHERE 1=1"
    params = []
    if q:
        sql += " AND (title LIKE ? OR company LIKE ? OR skills LIKE ?)"
        like = f"%{q}%"
        params.extend([like, like, like])
    if location:
        sql += " AND location LIKE ?"
        params.append(f"%{location}%")
    sql += " ORDER BY created_at DESC"
    jobs = conn.execute(sql, params).fetchall()
    conn.close()
    return render_template("jobs.html", jobs=jobs, q=q, location=location)

@app.route("/job/<int:job_id>")
def job_detail(job_id):
    conn = get_db()
    job = conn.execute("""
        SELECT jobs.*, users.name AS employer_name
        FROM jobs JOIN users ON jobs.employer_id=users.id
        WHERE jobs.id=?
    """, (job_id,)).fetchone()
    conn.close()
    if not job:
        flash("Job not found.", "danger")
        return redirect(url_for("jobs"))
    return render_template("job_detail.html", job=job)

@app.route("/employer/jobs/new", methods=["GET", "POST"])
@role_required("employer")
def create_job():
    if request.method == "POST":
        fields = [request.form["title"], request.form["company"], request.form["location"],
                  request.form["description"], request.form.get("skills",""), request.form.get("salary","")]
        conn = get_db()
        conn.execute("""
            INSERT INTO jobs(employer_id,title,company,location,description,skills,salary)
            VALUES(?,?,?,?,?,?,?)
        """, (session["user_id"], *fields))
        conn.commit()
        conn.close()
        flash("Job posted successfully.", "success")
        return redirect(url_for("dashboard"))
    return render_template("job_form.html", job=None)

@app.route("/employer/jobs/<int:job_id>/edit", methods=["GET", "POST"])
@role_required("employer")
def edit_job(job_id):
    conn = get_db()
    job = conn.execute("SELECT * FROM jobs WHERE id=? AND employer_id=?", (job_id, session["user_id"])).fetchone()
    if not job:
        conn.close()
        flash("Job not found or not owned by you.", "danger")
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        conn.execute("""
            UPDATE jobs SET title=?, company=?, location=?, description=?, skills=?, salary=?
            WHERE id=? AND employer_id=?
        """, (request.form["title"], request.form["company"], request.form["location"],
              request.form["description"], request.form.get("skills",""), request.form.get("salary",""),
              job_id, session["user_id"]))
        conn.commit()
        conn.close()
        flash("Job updated.", "success")
        return redirect(url_for("dashboard"))
    conn.close()
    return render_template("job_form.html", job=job)

@app.post("/employer/jobs/<int:job_id>/delete")
@role_required("employer", "admin")
def delete_job(job_id):
    conn = get_db()
    if session["role"] == "employer":
        conn.execute("DELETE FROM jobs WHERE id=? AND employer_id=?", (job_id, session["user_id"]))
    else:
        conn.execute("DELETE FROM jobs WHERE id=?", (job_id,))
    conn.execute("DELETE FROM applications WHERE job_id=?", (job_id,))
    conn.commit()
    conn.close()
    flash("Job deleted.", "success")
    return redirect(url_for("dashboard"))

@app.route("/job/<int:job_id>/apply", methods=["GET", "POST"])
@role_required("candidate")
def apply(job_id):
    conn = get_db()
    job = conn.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
    existing = conn.execute("SELECT id FROM applications WHERE job_id=? AND candidate_id=?",
                            (job_id, session["user_id"])).fetchone()
    if not job:
        conn.close()
        flash("Job not found.", "danger")
        return redirect(url_for("jobs"))
    if existing:
        conn.close()
        flash("You have already applied for this job.", "warning")
        return redirect(url_for("job_detail", job_id=job_id))

    if request.method == "POST":
        file = request.files.get("resume")
        filename = None
        if file and file.filename:
            if not allowed_file(file.filename):
                conn.close()
                flash("Resume must be PDF, DOC, or DOCX.", "danger")
                return redirect(request.url)
            filename = f"{session['user_id']}_{job_id}_{secure_filename(file.filename)}"
            file.save(UPLOAD_DIR / filename)

        conn.execute("""
            INSERT INTO applications(job_id,candidate_id,resume,cover_letter)
            VALUES(?,?,?,?)
        """, (job_id, session["user_id"], filename, request.form.get("cover_letter","")))
        conn.commit()
        conn.close()
        flash("Application submitted successfully.", "success")
        return redirect(url_for("dashboard"))

    conn.close()
    return render_template("apply.html", job=job)

@app.post("/application/<int:application_id>/status")
@role_required("employer", "admin")
def update_application(application_id):
    status = request.form["status"]
    allowed = {"Applied", "Shortlisted", "Interview", "Rejected", "Selected"}
    if status not in allowed:
        flash("Invalid status.", "danger")
        return redirect(url_for("dashboard"))
    conn = get_db()
    if session["role"] == "employer":
        conn.execute("""
            UPDATE applications SET status=?
            WHERE id=? AND job_id IN (SELECT id FROM jobs WHERE employer_id=?)
        """, (status, application_id, session["user_id"]))
    else:
        conn.execute("UPDATE applications SET status=? WHERE id=?", (status, application_id))
    conn.commit()
    conn.close()
    flash("Application status updated.", "success")
    return redirect(url_for("dashboard"))

@app.route("/uploads/<filename>")
@login_required
def uploaded_file(filename):
    return send_from_directory(UPLOAD_DIR, filename, as_attachment=True)

@app.post("/admin/users/<int:user_id>/delete")
@role_required("admin")
def delete_user(user_id):
    if user_id == session["user_id"]:
        flash("You cannot delete your own admin account.", "warning")
        return redirect(url_for("dashboard"))
    conn = get_db()
    conn.execute("DELETE FROM applications WHERE candidate_id=?", (user_id,))
    conn.execute("DELETE FROM jobs WHERE employer_id=?", (user_id,))
    conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()
    flash("User deleted.", "success")
    return redirect(url_for("dashboard"))

init_db()

if __name__ == "__main__":
    app.run(debug=True)
