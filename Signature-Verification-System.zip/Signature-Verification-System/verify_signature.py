import cv2

image = cv2.imread('sample_signature.png', cv2.IMREAD_GRAYSCALE)

if image is None:
    print('Please add sample_signature.png to test.')
else:
    print('Signature loaded:', image.shape)
