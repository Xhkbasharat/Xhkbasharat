# Human Emotion Detection System

## Objective
Detect human emotions from facial expressions using Deep Learning and Computer Vision.

## Emotions
- Happy
- Sad
- Angry
- Fear
- Surprise
- Neutral

## Technologies
- Python
- OpenCV
- TensorFlow/Keras
- Flask
- NumPy

## Run
pip install -r requirements.txt
python app.py
