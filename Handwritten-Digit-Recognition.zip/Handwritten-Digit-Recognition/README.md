# Handwritten Digit Recognition

## Objective
Recognize handwritten digits (0-9) using a Convolutional Neural Network (CNN).

## Technologies
- Python
- TensorFlow/Keras
- OpenCV
- NumPy
- Flask

## Dataset
MNIST Handwritten Digits Dataset

## Run
pip install -r requirements.txt
python app.py
