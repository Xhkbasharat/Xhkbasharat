document.addEventListener("DOMContentLoaded", () => {
  setTimeout(() => {
    document.querySelectorAll(".alert").forEach(el => {
      el.style.transition = "opacity .4s";
      el.style.opacity = "0.95";
    });
  }, 2500);
});
