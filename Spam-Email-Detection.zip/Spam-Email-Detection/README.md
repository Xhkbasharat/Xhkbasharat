# Spam Email Detection Using Machine Learning

## Objective
Classify messages as Spam or Ham using NLP and Machine Learning.

## Technologies
- Python
- Pandas
- Scikit-learn
- NLTK

## Run
pip install -r requirements.txt
python app.py
