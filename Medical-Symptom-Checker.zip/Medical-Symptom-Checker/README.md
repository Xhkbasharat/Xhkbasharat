# Medical Symptom Checker

Predict possible diseases from symptoms using Python and Machine Learning.

## Technologies
- Python
- Flask
- Pandas
- Scikit-learn

## Run
pip install -r requirements.txt
python app.py
