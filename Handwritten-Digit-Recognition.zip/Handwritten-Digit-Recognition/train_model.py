from tensorflow.keras.datasets import mnist

(X_train, y_train), (X_test, y_test) = mnist.load_data()

print("Training samples:", len(X_train))
print("Testing samples:", len(X_test))
