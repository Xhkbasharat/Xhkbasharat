from flask import Flask

app = Flask(__name__)

@app.route('/')
def home():
    return '<h1>Medical Symptom Checker</h1><p>Project setup ready.</p>'

if __name__ == '__main__':
    app.run(debug=True)
