# Plant Disease Detection Using Deep Learning

## Objective
Detect plant leaf diseases from uploaded images using a CNN model.

## Technologies
- Python
- TensorFlow
- OpenCV
- Flask
- NumPy

## Features
- Upload leaf image
- Predict disease
- Display result
- Web interface

## Run
pip install -r requirements.txt
python app.py
