# Expense Tracker

A simple Python Expense Tracker that records income and expenses using SQLite.

## Features
- Add income
- Add expenses
- View all transactions
- Calculate balance

## Run
pip install -r requirements.txt
python app.py
