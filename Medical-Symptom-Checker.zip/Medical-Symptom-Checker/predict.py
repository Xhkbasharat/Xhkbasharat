symptoms = ['fever', 'cough']

if 'fever' in symptoms and 'cough' in symptoms:
    print('Possible Disease: Flu')
